"""
Codeius AI Coding Agent
A powerful AI-powered coding assistant with multiple tools and visual interface.
"""

__version__ = "1.0.3"
__author__ = "MuhammadUsmanGM"
__email__ = "MuhammadUsmanGM@users.noreply.github.com"
